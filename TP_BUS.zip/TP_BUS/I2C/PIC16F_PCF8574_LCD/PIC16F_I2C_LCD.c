/*
 * Interfacing PIC16F877 microcontroller with I2C LCD screen
 * C Code for mikroC PRO for PIC compiler
 * Internal oscillator used @ 8MHz
*/


// include I2C LCD driver source file
#include "I2C_LCD.c"

char i = 0, text[4];

void main()
{
  //OSCCON = 0x70;  // set internal oscillator to 8MHz

  I2C1_Init(100000);   // initialize I2C bus with clock frequency of 100kHz

  LCD_Begin(0x4E);    // initialize LCD module with I2C address = 0x4E

  LCD_Goto(2, 1);     // move cursor to column 2, row 1
  LCD_Print("Hello ALINFO");

  while(1)
  {
    // store 'i' into 'text' ( '0' for ASCII format )
    text[0] =  i / 100      + '0';  // store hundreds
    text[1] = (i / 10) % 10 + '0';  // store tens
    text[2] =  i % 10       + '0';  // store ones

    LCD_Goto(7, 2);    // move cursor to column 7, row 2
    LCD_Print(text);   // print 'text'

    i++;             // increment i
    delay_ms(500);   // wait 0.5 second

  }

}