/**********************************************************************************
 * I2C_LCD.c                                                                      *
 * MikroC PRO for PIC compiler LCD driver for I2C LCDs with HD44780 compliant     *
 *   controllers.                                                                 *                                                  *
 *                                                                                *
 *********************************************************************************/


#include <stdint.h>


#ifndef  SOFT_I2C
  #define LCD_I2C_Start  I2C1_Start
  #define LCD_I2C_Write  I2C1_Wr
  #define LCD_I2C_Stop   I2C1_Stop
#else
  #define LCD_I2C_Start  Soft_I2C_Start
  #define LCD_I2C_Write  Soft_I2C_Write
  #define LCD_I2C_Stop   Soft_I2C_Stop
#endif

#define LCD_BACKLIGHT          0x08
#define LCD_NOBACKLIGHT        0x00
#define LCD_FIRST_ROW          0x80
#define LCD_SECOND_ROW         0xC0
#define LCD_THIRD_ROW          0x94
#define LCD_FOURTH_ROW         0xD4
#define LCD_CLEAR              0x01
#define LCD_RETURN_HOME        0x02
#define LCD_ENTRY_MODE_SET     0x04
#define LCD_CURSOR_OFF         0x0C
#define LCD_UNDERLINE_ON       0x0E
#define LCD_BLINK_CURSOR_ON    0x0F
#define LCD_MOVE_CURSOR_LEFT   0x10
#define LCD_MOVE_CURSOR_RIGHT  0x14
#define LCD_TURN_ON            0x0C
#define LCD_TURN_OFF           0x08
#define LCD_SHIFT_LEFT         0x18
#define LCD_SHIFT_RIGHT        0x1E

#ifndef LCD_TYPE
   #define LCD_TYPE 2           // 0=5x7, 1=5x10, 2=2 lines
#endif

void Expander_Write(uint8_t value);
void LCD_Write_Nibble(uint8_t n);
void LCD_Cmd_(uint8_t Command);
void LCD_Goto(uint8_t col, uint8_t row);
void LCD_PutC(char LCD_Char);
void LCD_Print(char* LCD_Str);
void LCD_Begin(uint8_t _i2c_addr);
void Backlight();
void noBacklight();

bit RS;
unsigned short i2c_addr, backlight_val = LCD_BACKLIGHT;

void Expander_Write(uint8_t value)
{
  LCD_I2C_Start();
  LCD_I2C_Write(i2c_addr);
  LCD_I2C_Write(value | backlight_val);
  LCD_I2C_Stop();
}

void LCD_Write_Nibble(uint8_t n)
{
  n |= RS;
  Expander_Write(n & 0xFB);
  delay_us(1);
  Expander_Write(n | 0x04);
  delay_us(1);
  Expander_Write(n & 0xFB);
  delay_us(100);
}

void LCD_Cmd_(uint8_t Command)
{
  RS = 0;
  LCD_Write_Nibble(Command & 0xF0);
  LCD_Write_Nibble((Command << 4) & 0xF0);
  if((Command == LCD_CLEAR) || (Command == LCD_RETURN_HOME))
    delay_ms(2);
}

void LCD_Goto(uint8_t col, uint8_t row)
{
  switch(row)
  {
    case 2:
      LCD_Cmd_(LCD_SECOND_ROW + col - 1);
      break;
    case 3:
      LCD_Cmd_(LCD_THIRD_ROW  + col - 1);
      break;
    case 4:
      LCD_Cmd_(LCD_FOURTH_ROW + col - 1);
    break;
    default:      // case 1:
      LCD_Cmd_(LCD_FIRST_ROW  + col - 1);
  }

}

void LCD_PutC(char LCD_Char)
{
  RS = 1;
  LCD_Write_Nibble(LCD_Char & 0xF0);
  LCD_Write_Nibble((LCD_Char << 4) & 0xF0);
}

void LCD_Print(char* LCD_Str)
{
  uint8_t i = 0;
  RS = 1;
  while(LCD_Str[i] != '\0')
  {
    LCD_Write_Nibble(LCD_Str[i] & 0xF0);
    LCD_Write_Nibble( (LCD_Str[i++] << 4) & 0xF0 );
  }
}

void LCD_Begin(uint8_t _i2c_addr)
{
  i2c_addr = _i2c_addr;
  Expander_Write(0);

  delay_ms(40);
  LCD_Cmd_(3);
  delay_ms(5);
  LCD_Cmd_(3);
  delay_ms(5);
  LCD_Cmd_(3);
  delay_ms(5);
  LCD_Cmd_(LCD_RETURN_HOME);
  delay_ms(5);
  LCD_Cmd_(0x20 | (LCD_TYPE << 2));
  delay_ms(50);
  LCD_Cmd_(LCD_TURN_ON);
  delay_ms(50);
  LCD_Cmd_(LCD_CLEAR);
  delay_ms(50);
  LCD_Cmd_(LCD_ENTRY_MODE_SET | LCD_RETURN_HOME);
  delay_ms(50);
}

void Backlight() {
  backlight_val = LCD_BACKLIGHT;
  Expander_Write(0);
}

void noBacklight() {
  backlight_val = LCD_NOBACKLIGHT;
  Expander_Write(0);
}