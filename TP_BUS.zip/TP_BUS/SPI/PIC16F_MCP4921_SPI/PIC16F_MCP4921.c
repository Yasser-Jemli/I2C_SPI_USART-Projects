// DAC module connections
sbit Chip_Select at RC0_bit;
sbit Chip_Select_Direction at TRISC0_bit;
void main() {
int value,h_b,l_b;
float num=0;
//la tension logique de l'appareil est de 5V, la tension de pas est de 5/4095 (
//4096-1 car le point de d�part pour le num�rique n'est pas 1, c'est 0), 
//soit 0,00122100122 millivolt. Ainsi, un changement de 1 bit changera la sortie 
//analogique de 0,00122100122.


while(1)
{
 for(num=0;num<=5;)
 {
  SPI1_Init();
  //SPI
  Chip_Select_Direction = 0; // Set CS# pin as Output
  value=num/0.001220703125;
  value=value|3 << 12; 
  h_b=(value>>8)& 255;
  l_b=value & 255;

  Chip_Select = 0;
  SPI1_Write(h_b);

  SPI1_Write(l_b);

  Chip_Select = 1;
  num=num+.1;

  }
 if(num==5)
   {
     for(num=5;num>=0;)
     {
       num=num-.1;
       SPI1_Init();
       //SPI
       Chip_Select_Direction = 0; // Set CS# pin as Output
       value=num/0.001220703125;
       value=value|3 << 12; 
       h_b=(value>>8)& 255;
       l_b=value & 255;

       Chip_Select = 0;
       SPI1_Write(h_b);

       SPI1_Write(l_b);
       Chip_Select = 1;

     }
   }
  }
}