#define BUFFER_SIZE 15

//Memory Card Chip Select Connection
sfr sbit Mmc_Chip_Select at RB2_bit;
sfr sbit Mmc_Chip_Select_Direction at TRISB2_bit;
//
// LCD module connections
sbit LCD_RS at RD0_bit;
sbit LCD_RW at RD1_bit;
sbit LCD_EN at RD2_bit;
sbit LCD_D4 at RD4_bit;
sbit LCD_D5 at RD5_bit;
sbit LCD_D6 at RD6_bit;
sbit LCD_D7 at RD7_bit;

sbit LCD_RS_Direction at TRISD0_bit;
sbit LCD_EN_Direction at TRISD2_bit;
sbit LCD_D4_Direction at TRISD4_bit;
sbit LCD_D5_Direction at TRISD5_bit;
sbit LCD_D6_Direction at TRISD6_bit;
sbit LCD_D7_Direction at TRISD7_bit;
// End LCD module connections

unsigned char filename[] = "Temp.TXT";
unsigned char error;
unsigned char i;
unsigned int adc_value;
unsigned char Temperature_Log[BUFFER_SIZE];
void main()
{
 unsigned char ones,tens,hundreds;
 unsigned int temp;
 
 TRISD = 0x00;
 Lcd_Init();
 Lcd_Cmd(_LCD_CURSOR_OFF);
 Lcd_Cmd(_LCD_CLEAR);
 Delay_ms(100);
 Lcd_Out(1,1," TEMP. RECORDER");
 Lcd_Out(2,1,"  SYSTEME DE BUS");
 Delay_ms(1000);
 
 ADCON0 = 0b00000001;    //A/D Converter Power Up
 ADCON1 = 0x00;          //All Analog Channels
 ADCON2 = 0b10111110;    //Right Justfied and Slowest Clock for better accuracy
 ADC_Init();
 
 SPI1_Init();
 SPI1_Init_Advanced(_SPI_MASTER_OSC_DIV64, _SPI_DATA_SAMPLE_MIDDLE, _SPI_CLK_IDLE_LOW, _SPI_LOW_2_HIGH);
 Delay_us(10);
 
 error = MMC_Init();
 while(error == 1)
 {
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Out(1,1," CARD NOT FOUND");
  error = MMC_Init();
 }
 
 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Out(1,1," CARD DETECTED!");
 Lcd_Out(2,1,"CARD INITIALIZED");
 Delay_ms(1000);
 
 MMC_Fat_Init();
 SPI1_Init_Advanced(_SPI_MASTER_OSC_DIV4, _SPI_DATA_SAMPLE_MIDDLE, _SPI_CLK_IDLE_LOW, _SPI_LOW_2_HIGH);
 
 Mmc_Fat_Assign(&filename,0xA0);
 
 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Out(1,1,"TEMPERATURE:");
 
 while(1)
 {
  adc_value = ADC_Read(0);      //Read Temperature from ADC
  adc_value = adc_value*488;
  adc_value = adc_value/10;
  
  temp = adc_value/100;
  
  Temperature_Log[0] = 'T';
  Temperature_Log[1] = 'E';
  Temperature_Log[2] = 'M';
  Temperature_Log[3] = 'P';
  Temperature_Log[4] = '=';
  
  ones = temp%10;
  temp = temp/10;
  tens = temp%10;
  temp = temp/10;
  hundreds = temp%10;
  
  ones = ones|0x30;
  tens = tens|0x30;
  hundreds = hundreds|0x30;

  Temperature_Log[5] = hundreds;
  Temperature_Log[6] = tens;
  Temperature_Log[7] = ones;
  Temperature_Log[8] = '.';
  
  Lcd_Chr(2,1,hundreds);
  Lcd_Chr(2,2,tens);
  Lcd_Chr(2,3,ones);
  
  ones = adc_value%10;
  adc_value = adc_value/10;
  tens = adc_value%10;
  ones = ones|0x30;
  tens = tens|0x30;
  
  Temperature_Log[9] = tens;
  Temperature_Log[10] = ones;
  Temperature_Log[11] = ' ';
  Temperature_Log[12] = 'C';
  Temperature_Log[13] = '\r';
  Temperature_Log[14] = '\n';
  
  Lcd_Chr(2,4,'.');
  Lcd_Chr(2,5,tens);
  Lcd_Chr(2,6,ones);
  Lcd_Chr(2,7,223);
  Lcd_Chr(2,8,'C');
  Mmc_Fat_Append();
  Mmc_Fat_Write(Temperature_Log,15);
  Delay_ms(300);
 }
}