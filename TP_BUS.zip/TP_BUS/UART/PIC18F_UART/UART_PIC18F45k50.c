
// LCD module connections
sbit LCD_RS at LATD0_bit;
sbit LCD_EN at LATD1_bit;
sbit LCD_D4 at LATD4_bit;
sbit LCD_D5 at LATD5_bit;
sbit LCD_D6 at LATD6_bit;
sbit LCD_D7 at LATD7_bit;

sbit LCD_RS_Direction at TRISD0_bit;
sbit LCD_EN_Direction at TRISD1_bit;
sbit LCD_D4_Direction at TRISD4_bit;
sbit LCD_D5_Direction at TRISD5_bit;
sbit LCD_D6_Direction at TRISD6_bit;
sbit LCD_D7_Direction at TRISD7_bit;
// End LCD module connections

char uart_rd;
// Pour les PIC18F on utilise l'instruction LAT au lieu de PORT pour
// faire sortir une valeur par un port dE/S

void main() {

OSCCON = 0X70; // Set internal oscillator to 8MHz
ADCON1 = 0x0F; // Configure AN pins as digital
//CMCON = 7; // Disable comparators

TRISC.F6 = 0; //direction of Tx and Rx pins
TRISC.F7 = 1;

TRISB=0x00;
LATB=0;
TRISD=0x00;
LATD=0;
UART1_Init(9600);
delay_ms(100);

Lcd_Init(); // Inicializa LCD
Lcd_Cmd(_Lcd_CLEAR); // Limpiar display
Lcd_Cmd(_Lcd_CURSOR_OFF); // Desactivar cursor

UART1_Write_Text("MON A, B OR C NIGGA\r\n");
delay_ms(1000);

LATD.F3=1;
delay_ms(500);
LATD.F3=0;
delay_ms(500);
LATB=0b00000111;
delay_ms(1000);
LATB=0b00000000;
delay_ms(1000);

Lcd_Out(1,1,"COMMUNICATION");
Lcd_Out(2,1,"START");
while(1){
         if(UART1_Data_Ready()){
         uart_rd = UART1_Read();
         LATD.F2=1;
         delay_ms(500);
         LATD.F2=0;
         delay_ms(500);

switch(uart_rd){
         case 'A':LATB.F0=1;
                LATB.F1=0;
                LATB.F2=0;
                UART1_Write_Text("\r\nBAD GUY\r\n");
                Lcd_Cmd(_Lcd_CLEAR);
                Lcd_Out(1,1,"COMMUNICATION A");
                Lcd_Out(2,1,"COMMUNICATION A");
                Lcd_Out(3,1,"COMMUNICATION A");
                Lcd_Out(4,1,"COMMUNICATION A");
                delay_ms(500);
break;
         case 'B':LATB.F0=0;
                LATB.F1=1;
                LATB.F2=0;
                UART1_Write_Text("\r\nSOLO DIOS PUEDE JUZGARME BRRRRRRRRR\r\n");
                Lcd_Cmd(_Lcd_CLEAR);
                Lcd_Out(1,1,"COMMUNICATION B");
                Lcd_Out(2,1,"COMMUNICATION B");
                Lcd_Out(3,1,"COMMUNICATION B");
                Lcd_Out(4,1,"COMMUNICATION B");
                delay_ms(500);
break;
         case 'C':LATB.F0=0;
                LATB.F1=0;
                LATB.F2=1;
                UART1_Write_Text("\r\nJUDSHON! JUDSHON! SOSH UNA BASHURA COSHMICA\r\n");
                Lcd_Cmd(_Lcd_CLEAR);
                Lcd_Out(1,1,"COMMUNICATION C");
                Lcd_Out(2,1,"COMMUNICATION C");
                Lcd_Out(3,1,"COMMUNICATION C");
                Lcd_Out(4,1,"COMMUNICATION C");
                delay_ms(500);
break;
}
}
}
}